/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/js/view/advanced-tabs.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/js/view/advanced-tabs.js":
/*!**************************************!*\
  !*** ./src/js/view/advanced-tabs.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var advancedTabs = function advancedTabs($scope, $) {\n  // Glassey tab bar style\n  var $glasseyTabs = $scope.find(\".eael-tabs-glassey\");\n  if ($glasseyTabs.length) {\n    initGlasseyTabStyle($glasseyTabs);\n  }\n\n  /**\n   * Initialize dynamic Glassey tab bar style\n   */\n  function initGlasseyTabStyle($glasseyTabs) {\n    $glasseyTabs.each(function () {\n      var $tabContainer = $(this);\n      var $tabsList = $tabContainer.find(\"ul\");\n      var $tabs = $tabsList.find(\"li\");\n      var widgetId = $tabContainer.closest(\".eael-advance-tabs\").attr(\"id\");\n      if (!widgetId || $tabs.length === 0) {\n        return;\n      }\n\n      // Generate unique style ID for this widget instance\n      var styleId = \"eael-glassey-style-\" + widgetId;\n\n      // Remove existing style if it exists\n      $(\"#\" + styleId).remove();\n\n      // Calculate tab widths and positions\n      updateGlasseyTabPositions($tabContainer, $tabs, styleId);\n\n      // Update positions on window resize\n      $(window).on(\"resize.glassey-\" + widgetId, function () {\n        updateGlasseyTabPositions($tabContainer, $tabs, styleId);\n      });\n\n      // Update positions when tabs are clicked\n      $tabs.on(\"click.glassey\", function () {\n        setTimeout(function () {\n          updateGlasseyTabPositions($tabContainer, $tabs, styleId);\n        }, 50);\n      });\n    });\n  }\n\n  /**\n   * Update Glassey tab positions and generate dynamic CSS\n   */\n  function updateGlasseyTabPositions($tabContainer, $tabs, styleId) {\n    var widgetId = $tabContainer.closest(\".eael-advance-tabs\").attr(\"id\");\n    var cssRules = \"\";\n    $tabs.each(function () {\n      var $tab = $(this);\n      var tabNumber = $tab.data(\"tab\");\n      var tabPosition = $tab.position();\n      var tabWidth = $tab.outerWidth();\n      var tabHeight = $tab.outerHeight();\n      if (tabPosition && typeof tabPosition.left !== \"undefined\" && tabWidth) {\n        var translateX = Math.round(tabPosition.left);\n        var translateY = Math.round(tabPosition.top);\n        var dynamicWidth = Math.round(tabWidth - 8);\n        var dynamicHeight = Math.round(tabHeight - 8);\n        cssRules += \"\\n                        #\".concat(widgetId, \" .eael-tabs-glassey > ul:has(li.active[data-tab=\\\"\").concat(tabNumber, \"\\\"])::after {\\n                           translate: \").concat(translateX, \"px \").concat(translateY, \"px;\\n                           width: \").concat(dynamicWidth, \"px;\\n                           height: \").concat(dynamicHeight, \"px;\\n                           transform-origin: right;\\n                           transition: background-color 400ms cubic-bezier(1, 0, 0.4, 1),\\n                                 box-shadow 400ms cubic-bezier(1, 0, 0.4, 1),\\n                                 translate 400ms cubic-bezier(1, 0, 0.4, 1),\\n                                 width 400ms cubic-bezier(1, 0, 0.4, 1);\\n                           animation: scaleToggle 440ms ease;\\n                        }\\n                     \");\n      }\n    });\n\n    // Create or update the style element\n    if (cssRules) {\n      var $styleElement = $(\"#\" + styleId);\n      if ($styleElement.length === 0) {\n        $styleElement = $(\"<style>\", {\n          id: styleId,\n          type: \"text/css\"\n        });\n        $(\"head\").append($styleElement);\n      }\n      $styleElement.html(cssRules);\n    }\n  }\n};\njQuery(window).on(\"elementor/frontend/init\", function () {\n  if (eael.elementStatusCheck(\"advancedTabs\")) {\n    return false;\n  }\n  elementorFrontend.hooks.addAction(\"frontend/element_ready/eael-adv-tabs.default\", advancedTabs);\n});\n\n//# sourceURL=webpack:///./src/js/view/advanced-tabs.js?");

/***/ })

/******/ });